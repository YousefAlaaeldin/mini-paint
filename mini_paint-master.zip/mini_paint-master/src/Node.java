
public interface Node {
    public void setParentNode(Node parentNode);
    public Node getParentNode();
}
